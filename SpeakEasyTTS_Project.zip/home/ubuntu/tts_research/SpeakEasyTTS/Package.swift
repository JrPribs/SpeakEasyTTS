// swift-tools-version: 5.9
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "SpeakEasyTTS",
    platforms: [
        .macOS(.v14)
    ],
    products: [
        .executable(name: "SpeakEasyTTS", targets: ["SpeakEasyTTS"])
    ],
    dependencies: [],
    targets: [
        .executableTarget(
            name: "SpeakEasyTTS",
            dependencies: [],
            path: "Sources",
            resources: [
                .process("Resources")
            ]
        )
    ]
)
